package Model;

public interface person {
    void set_age(int age);
    int get_age();
    void set_nationality(String nationality);
    String get_nationality();

}
